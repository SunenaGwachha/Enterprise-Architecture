package edu.mum.ea.elasticsearchservice.model;

public class Address {
}
