package edu.mum.ea.elasticsearchservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElasticsearchServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
