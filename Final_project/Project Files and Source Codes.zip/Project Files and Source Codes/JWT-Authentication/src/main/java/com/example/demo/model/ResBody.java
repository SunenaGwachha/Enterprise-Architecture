package com.example.demo.model;

public class ResBody {
	String message;
	public ResBody() {
		
	}
	public ResBody(String msg) {
		this.message=msg;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	

}
