package com.example.demo;

class Demo1ApplicationTests {

	void contextLoads() {
	}

}
