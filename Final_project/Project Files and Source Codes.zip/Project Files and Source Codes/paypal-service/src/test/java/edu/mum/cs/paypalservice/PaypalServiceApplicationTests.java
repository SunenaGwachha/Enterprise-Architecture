package edu.mum.cs.paypalservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaypalServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
